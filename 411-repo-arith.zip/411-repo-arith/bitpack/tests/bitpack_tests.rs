// tests/bitpack_tests.rs

use bitpack::bitpack::*;

#[cfg(test)]
mod tests {
    // Import the necessary items from the bitpack module
    use super::*;

    #[test]
    fn fitss_check() {
        assert_eq!(true,fitss(-16, 5));
        assert_eq!(true,fitss(15, 5));
        assert_eq!(false,fitss(5, 3));
        assert_eq!(false, fitss(18, 5));
    }

    #[test]
    fn fitsu_check() {
        assert!(fitsu(6, 3));
        assert_eq!(true,fitsu(0, 5));
        assert_eq!(true,fitsu(31, 5));
        assert_eq!(true, fitsu(18, 5));
    }

    #[test]
    fn gets_check() {
        assert_eq!(gets(0x3f4, 6, 2), -3);
        assert_eq!(9, gets(36, 5, 2));
    }

    #[test]
    fn getu_check() {
        assert_eq!(getu(0x3f4, 6, 2), 61);
        assert_eq!(9, getu(36, 4, 2));
    }

    #[test]
    fn newu_check() {
        assert_eq!(36, newu(0, 8, 23, 139).unwrap());
    }

    #[test]
    fn news_check() {
        assert_eq!(36, news(0, 4, 2, 9).unwrap());
    }


    // Add more test functions for other functions in bitpack.rs
}
