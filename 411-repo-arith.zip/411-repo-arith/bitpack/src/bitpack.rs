use std::convert::TryInto;

//Width-test functions

/// Returns true iff the signed value `n` fits into `width` signed bits.
///
/// # Arguments:
/// * `n`: A signed integer value
/// * `width`: the width of a bit field
///

pub fn fitss(n: i64, width: u64) -> bool {
    let min_value = i64::min_value() >> (64 - width)-1;
    let max_value = i64::max_value() >> (64 - width);
    n >= min_value && n <= max_value
}


/// Returns true iff the unsigned value `n` fits into `width` unsigned bits.
///
/// # Arguments:
/// * `n`: An usigned integer value
/// * `width`: the width of a bit field
pub fn fitsu(n: u64, width: u64) -> bool {
    n <= u64::max_value() >> (64 - width)
}


// Field-extraction functions


/// Retrieve a signed value from `word`, represented by `width` bits
/// beginning at least-significant bit `lsb`.
///
/// # Arguments:
/// * `word`: An unsigned word
/// * `width`: the width of a bit field
/// * `lsb`: the least-significant bit of the bit field
pub fn gets(word: u64, width: u64, lsb: u64) -> i64 {
    let mask = (1u64 << width) - 1;
    let sign_bit = (word >> (lsb + width - 1)) & 1;
    let value = (word >> lsb) & mask;
    if sign_bit == 1 {
        // Sign extend the value if the sign bit is set
        (value | !mask) as i64
    } else {
        value as i64
    }
}

/// Retrieve an unsigned value from `word`, represented by `width` bits
/// beginning at least-significant bit `lsb`.
///
/// # Arguments:
/// * `word`: An unsigned word
/// * `width`: the width of a bit field
/// * `lsb`: the least-significant bit of the bit field
pub fn getu(word: u64, width: u64, lsb: u64) -> u64 {
    (word >> lsb) & ((1u64 << width) - 1)
}

// Field-update functions

/// Return a modified version of the unsigned `word`,
/// which has been updated so that the `width` bits beginning at
/// least-significant bit `lsb` now contain the unsigned `value`.
/// Returns an `Option` which will be None iff the value does not fit
/// in `width` unsigned bits.
///
/// # Arguments:
/// * `word`: An unsigned word
/// * `width`: the width of a bit field
/// * `lsb`: the least-significant bit of the bit field
/// * `value`: the unsigned value to place into that bit field
pub fn newu(word: u64, width: u64, lsb: u64, value: u64) -> Option<u64> {
    if fitsu(value, width) {
        let original_bits = getu(word, width, lsb);
        let mask = !(((1u64 << width) - 1) << lsb);
        let result = (word & mask) | ((value & ((1u64 << width) - 1)) << lsb) | (original_bits << lsb);

        println!("Original bits: {}", original_bits);
        println!("Mask: {}", mask);
        println!("Result: {}", result);

        Some(result)
    } else {
        None
    }
}




/// Return a modified version of the unsigned `word`,
/// which has been updated so that the `width` bits beginning at
/// least-significant bit `lsb` now contain the signed `value`.
/// Returns an `Option` which will be None iff the value does not fit
/// in `width` signed bits.
///
/// # Arguments:
/// * `word`: An unsigned word
/// * `width`: the width of a bit field
/// * `lsb`: the least-significant bit of the bit field
/// * `value`: the signed value to place into that bit field
pub fn news(word: u64, width: u64, lsb: u64, value: i64) -> Option<u64> {
    if fitss(value, width) {
        let original_bits = gets(word, width, lsb) as u64; // Cast original_bits to u64
        let mask = !(((1u64 << width) - 1) << lsb);
        Some((word & mask) | (((value as u64) & ((1u64 << width) - 1)) << lsb) | (original_bits << lsb))
    } else {
        None
    }
}

